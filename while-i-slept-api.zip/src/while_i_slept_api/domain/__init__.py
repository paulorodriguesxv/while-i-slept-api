"""Domain models."""

