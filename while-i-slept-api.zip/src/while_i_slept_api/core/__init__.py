"""Core utilities and configuration."""

