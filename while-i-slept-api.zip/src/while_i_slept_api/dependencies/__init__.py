"""Dependency providers for FastAPI."""

